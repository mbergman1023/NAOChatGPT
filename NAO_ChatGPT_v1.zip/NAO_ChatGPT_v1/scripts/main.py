# NAO ChatGPT V1

import qi
import argparse
import sys
import time
import numpy as np
import requests
import wave
import io

INTERMEDIATE_SERVER_URL = "http://192.168.33.40:5000/transcribe"  # Double check IP of server

class SoundProcessingModule(object):
    def __init__(self, app):
        """
        Initialize the SoundProcessingModule.
        """
        super(SoundProcessingModule, self).__init__()
        app.start()
        session = app.session
        self.audio_service = session.service("ALAudioDevice")  
        self.tts_service = session.service("ALAnimatedSpeech") 
        self.logger = qi.Logger("SoundProcessingModule") 
        self.isProcessingDone = False  # Flag to check if processing is done
        self.framesCount = 0  # Counter for the number of audio frames processed
        self.micFront = []  # List to store audio data from the microphone
        self.module_name = "SoundProcessingModule"  # Name the module
        self.start_time = None  # start time of listening
        self.listen_duration = 10  # Duration to listen in seconds

    def startProcessing(self):
        """
        Start processing the audio input.
        """
        self.tts_service.say("Hello, what can I do for you?")  # Prompt user to start talking
        self.logger.info("I am ready to listen.")  # Log that robot is ready to listen
        self.audio_service.setClientPreferences(self.module_name, 16000, 3, 0)  # Set audio preferences (name, sample rate, cahnnels, deinterleaving..?)
        self.audio_service.subscribe(self.module_name)  # Subscribe to the audio service
        self.start_time = time.time()  # set start time

        while not self.isProcessingDone:  # Loop until processing is done
            time.sleep(1)

        self.audio_service.unsubscribe(self.module_name)  # Unsubscribe from the audio service
        self.tts_service.say("I'll need to think about this for a second.")  # prompt that robot is processing
        self.logger.info("I have finished listening.")
        audio_data = self.convertToWavBytes(self.micFront)  # Convert audio to WAV format
        self.logger.info("WAV file data (first 100 bytes): {}".format(audio_data[:100]))  # log first 100 bytes for verification
        self.sendDataToServer(audio_data)  # Send audio to the server

    def processRemote(self, nbOfChannels, nbOfSamplesByChannel, timeStamp, inputBuffer):
        """
        Process the audio input received from the robot's microphone.
        """
        current_time = time.time()
        if current_time - self.start_time <= self.listen_duration:  # Check if listening duration has not been exceeded
            self.framesCount += 1
            self.micFront.extend(self.convertStr2SignedInt(inputBuffer))  # Convert input buffer to signed integers and append to micFront
        else:
            self.isProcessingDone = True  # processing finished

    def convertStr2SignedInt(self, data):
        """
        Convert a string of bytes to a list of signed integers.
        """
        signedData = []
        ind = 0
        for i in range(0, len(data) // 2):  # Iterate through data, integer division
            # Convert bytes to signed ints
            signed_value = int(data[ind]) + int(data[ind + 1]) * 256
            if signed_value >= 32768:
                signed_value = signed_value - 65536
            signedData.append(signed_value)
            ind += 2
        return signedData

    def convertToWavBytes(self, signedData):
        """
        Convert a list of signed integers to WAV format bytes.
        """
        byte_io = io.BytesIO()  # Create a BytesIO object to hold audio
        wav_file = wave.open(byte_io, 'wb')  # Open file to write
        wav_file.setnchannels(1)  # Set number of channels to 1 (mono)
        wav_file.setsampwidth(2)  # Set sample width to 2 bytes (16 bits)
        wav_file.setframerate(16000)  # Set frame rate to 16000 Hz
        wav_file.writeframes(np.array(signedData, dtype=np.int16).tobytes())  # Write frames to the WAV file
        wav_file.close()  # Close WAV file
        return byte_io.getvalue()  # Get WAV data as bytes

    def sendDataToServer(self, audio_data):
        """
        Send the WAV file data to the server.
        """
        self.logger.info("Sending data to server")
        try:
            response = requests.post(INTERMEDIATE_SERVER_URL, data=audio_data)  # Send audio data to the server
            if response.status_code == 200:  # Check if request was successful
                gpt_response = response.json()
                if 'response' in gpt_response:
                    chatgpt_text = gpt_response['response']
                    self.tts_service.say(chatgpt_text)  # say the ChatGPT response
                    self.logger.info("ChatGPT response: " + chatgpt_text)  # Log the ChatGPT response
                else:
                    self.tts_service.say("Error in response from server: {}".format(gpt_response.get('error')))  # Handle error in server response
                    self.logger.error("Error in response from server: {}".format(gpt_response.get('error')))
            else: # error messages
                error_msg = "Error: Received response code {}".format(response.status_code)  
                self.tts_service.say(error_msg)  # say and log error message
                self.logger.error(error_msg) 
        except requests.exceptions.RequestException as e:
            error_msg = "Error sending data: {}".format(e)
            self.tts_service.say(error_msg) 
            self.logger.error(error_msg) 

if __name__ == "__main__":
    parser = argparse.ArgumentParser() 
    parser.add_argument("--ip", type=str, default="127.0.0.1", help="Robot IP address. On robot or Local Naoqi: use '127.0.0.1'.") 
    parser.add_argument("--port", type=int, default=9559, help="Naoqi port number") 
    args = parser.parse_args()
    try:
        connection_url = "tcp://{0}:{1}".format(args.ip, str(args.port)) 
        app = qi.Application(["SoundProcessingModule", "--qi-url=" + connection_url]) 
    except RuntimeError:
        error_msg = "Can't connect to Naoqi at ip {0} on port {1}. Please check your script arguments. Run with -h option for help.".format(args.ip, args.port)  
        print(error_msg) e
        sys.exit(1) 
    MySoundProcessingModule = SoundProcessingModule(app)  # Create instance of SoundProcessingModule
    app.session.registerService("SoundProcessingModule", MySoundProcessingModule)  # Register service
    MySoundProcessingModule.startProcessing()  # Start processing
